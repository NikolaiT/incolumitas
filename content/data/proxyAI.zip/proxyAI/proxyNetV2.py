import tensorflow as tf
import json
import sys
import matplotlib as mpl
import numpy as np
import matplotlib.pyplot as plt
import random
from sklearn.metrics import confusion_matrix
import seaborn as sns
from tensorflow import keras
import logging

tf.get_logger().setLevel(logging.ERROR)
mpl.rcParams['figure.figsize'] = (12, 10)
colors = plt.rcParams['axes.prop_cycle'].by_key()['color']

MODEL_DIR = 'skynet'
EPOCHS = 100
BATCH_SIZE = 2048
METRICS = [
    keras.metrics.TruePositives(name='tp'),
    keras.metrics.FalsePositives(name='fp'),
    keras.metrics.TrueNegatives(name='tn'),
    keras.metrics.FalseNegatives(name='fn'),
    keras.metrics.BinaryAccuracy(name='accuracy'),
    keras.metrics.Precision(name='precision'),
    keras.metrics.Recall(name='recall'),
    keras.metrics.AUC(name='auc'),
    keras.metrics.AUC(name='prc', curve='PR'),  # precision-recall curve
]


def loadData(filePath):
    images = []
    if filePath.endswith('.npz'):
        dataFile = np.load(filePath)
        for file in dataFile.files:
            images.append(dataFile[file])
    elif filePath.endswith('.json'):
        with open(filePath, 'r') as fp:
            images = json.load(fp)
            images = [np.array(image) for image in images]
    print('Loaded {} images from file {}'.format(len(images), filePath))
    return images


def getClassifyingData(data, treshold=0.90):
    numTraining = int(len(data) * treshold)

    training_data, testing_data = data[:numTraining], data[numTraining:]

    train_labels, train_images = np.array(
        [e[0] for e in training_data]), np.array([e[1] for e in training_data])

    test_labels, test_images = np.array(
        [e[0] for e in testing_data]), np.array([e[1] for e in testing_data])

    return (train_labels, train_images), (test_labels, test_images)


class_names = ['noProxy', 'proxy']
proxy_images_complete = loadData('./dataSets/proxy-images.json')
no_proxy_images = loadData('./dataSets/non-proxy-images.json')
num_total_images = len(proxy_images_complete) + len(no_proxy_images)

random.shuffle(proxy_images_complete)
random.shuffle(no_proxy_images)

imgToLabelArray = []

for pi in proxy_images_complete:
    imgToLabelArray.append((1, pi))

for npi in no_proxy_images:
    imgToLabelArray.append((0, npi))

random.shuffle(imgToLabelArray)

print('Having {}/{} proxy flows in dataset'.format(len(proxy_images_complete),
      len(imgToLabelArray)))
print('Having {}/{} non-proxy flows in dataset'.format(len(no_proxy_images),
      len(imgToLabelArray)))

(train_labels, train_images), (test_labels,
                               test_images) = getClassifyingData(imgToLabelArray)

print('Number of train_images', train_images.shape)
print('Number of test_images', test_images.shape)

train_images = train_images / 255.0
test_images = test_images / 255.0


def make_model(metrics=METRICS, output_bias=None):
    if output_bias is not None:
        output_bias = tf.keras.initializers.Constant(output_bias)
    model = keras.Sequential([
        keras.layers.Flatten(input_shape=(9, 9)),
        keras.layers.Dense(
            128, activation='relu'),
        keras.layers.Dropout(0.5),
        keras.layers.Dense(1, activation='sigmoid',
                           bias_initializer=output_bias),
    ])

    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=1e-3),
        loss=keras.losses.BinaryCrossentropy(),
        metrics=metrics)

    return model


def plot_metrics(history):
    metrics = ['loss', 'prc', 'precision', 'recall']
    for n, metric in enumerate(metrics):
        name = metric.replace("_", " ").capitalize()
        plt.subplot(2, 2, n+1)
        plt.plot(history.epoch,
                 history.history[metric], color=colors[0], label='Train')
        plt.plot(history.epoch, history.history['val_'+metric],
                 color=colors[0], linestyle="--", label='Val')
        plt.xlabel('Epoch')
        plt.ylabel(name)
        if metric == 'loss':
            plt.ylim([0, plt.ylim()[1]])
        elif metric == 'auc':
            plt.ylim([0.8, 1])
        else:
            plt.ylim([0, 1])

        plt.legend()
        plt.savefig('./img/metrics.png')


def plot_cm(labels, predictions, p=0.5):
    cm = confusion_matrix(labels, predictions > p)
    plt.figure(figsize=(5, 5))
    sns.heatmap(cm, annot=True, fmt="d")
    plt.title('Confusion matrix @{:.2f}'.format(p))
    plt.ylabel('Actual label')
    plt.xlabel('Predicted label')
    plt.savefig('./img/cm.png')

    print(
        'Non-Proxy Flows Detected as Non-Proxy Flows (True Negatives): ', cm[0][0])
    print(
        'Non-Proxy Flows Detected as Proxy Flows (False Positives): ', cm[0][1])
    print(
        'Proxy Flows Detected as Non-Proxy Flows (False Negatives): ', cm[1][0])
    print('Proxy Flows Detected as Proxy Flows (True Positives): ', cm[1][1])
    print('Total Proxy Flows: ', np.sum(cm[1]))


def train_model():
    # Scaling by total/2 helps keep the loss to a similar magnitude.
    # The sum of the weights of all examples stays the same.
    weight_for_non_proxy = (1 / len(no_proxy_images)) * \
        (num_total_images / 2.0)
    weight_for_proxy = (1 / len(proxy_images_complete)) * \
        (num_total_images / 2.0)
    class_weight = {0: weight_for_non_proxy, 1: weight_for_proxy}
    print('Weight for class non-proxy: {:.2f}'.format(weight_for_non_proxy))
    print('Weight for class proxy: {:.2f}'.format(weight_for_proxy))

    early_stopping = tf.keras.callbacks.EarlyStopping(
        monitor='val_prc',
        verbose=1,
        patience=10,
        mode='max',
        restore_best_weights=True)

    initial_bias = np.log([len(proxy_images_complete)/len(no_proxy_images)])
    model = make_model(output_bias=initial_bias)
    # model.load_weights(initial_weights)
    print(model.summary())

    weighted_history = model.fit(
        train_images,
        train_labels,
        batch_size=BATCH_SIZE,
        epochs=EPOCHS,
        callbacks=[early_stopping],
        validation_data=(test_images, test_labels),
        # The class weights go here
        class_weight=class_weight)

    model.save('skynet')
    print('Saved model to directory skynet/')
    plot_metrics(weighted_history)
    plt.show()


def test_model():
    model = keras.models.load_model('skynet')
    baseline_results = model.evaluate(test_images, test_labels,
                                      batch_size=BATCH_SIZE, verbose=0)
    for name, value in zip(model.metrics_names, baseline_results):
        print(name, ': ', value)
    print()

    train_predictions_baseline = model.predict(
        train_images, batch_size=BATCH_SIZE)
    test_predictions_baseline = model.predict(
        test_images, batch_size=BATCH_SIZE)

    plot_cm(test_labels, test_predictions_baseline)
    plt.show()


if sys.argv[1] == 'train':
    train_model()
elif sys.argv[1] == 'test':
    test_model()
