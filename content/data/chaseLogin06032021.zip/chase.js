/**
 * Install: npm i ghost-cursor puppeteer-core
 * 
 * /usr/bin/google-chrome-stable needs to be latest Google Chrome browser.
 * 
 * Very basic attempt to evade Shape Security evasions with
 * google-chrome-stable (installed instead of chromium)
 * and ghost-cursor.
 * 
 * Tries to Login to the chase bank.
 * 
 * Limit: browser fingerprinting will limit this approach.
 * Reason: when you put this script in a Docker image with the  
 * Google Chrome browser and then you run it in parallel on 100 servers,
 * each instance will have the same browser fingerprint. 
 * 
 * Then shape security will likely block it.
 * 
 * Same goes for canvas and audio fingeprint.
 */

const createCursor = require("ghost-cursor").createCursor;
const puppeteer = require('puppeteer-core');
const exec = require('child_process').exec;
const fs = require('fs');

// change this mofo when necessary
const GOOGLE_CHROME_BINARY = '/usr/bin/google-chrome-stable';

function sleep(ms) {
 return new Promise(resolve => setTimeout(resolve, ms));
}

function execute(command, callback){
 exec(command, function(error, stdout, stderr){ callback(stdout); });
}

/**
 * Returns a random number between min (inclusive) and max (exclusive)
 */
function randRange(min, max) {  
  return Math.floor(
    Math.random() * (max - min) + min
  )
}

/**
* Poll browser.log periodically until we see the wsEndpoint
* that we use to connect to the browser.
*/
async function getWsEndpoint() {
 let wsEndointFile = './browser.log';
 for (let i = 1; i <= 10; i++) {
   await sleep(500);
   if (fs.existsSync(wsEndointFile)) {
     let logContents = fs.readFileSync(wsEndointFile).toString();
     var regex = /DevTools listening on (.*)/gi;
     let match = regex.exec(logContents);
     if (match) {
       return match[1];
     }
   }
 }
 console.log('Could not get wsEndpoint');
 process.exit(0);
}

/**
* Login to chase.com with the help of ghost cursor 
* and some random relays when entering the credentials.
*/
async function chaseLogin(page, frame) {
  const cursor = createCursor(page);
  await frame.waitForSelector('#signin-button');

  // click on username input with ghost cursor
  // and enter password
  const userNameInput = await frame.$('#userId-text-input-field');
  await cursor.click(userNameInput);

  for (let char of process.env.CHASE_USER) {
    await userNameInput.type(char, {delay: randRange(10, 30)});
  }

  await sleep(randRange(100, 700));

  // click on pass input with ghost cursor
  const passwordInput = await frame.$('#password-text-input-field');
  await cursor.click(passwordInput);

  for (let char of process.env.CHASE_PASS) {
    await passwordInput.type(char, {delay: randRange(10, 30)});
  }

  await sleep(randRange(100, 700));

  // enable remember me
  const remeberMe = await frame.$('#label-rememberMe');
  await cursor.click(remeberMe);

  await sleep(randRange(100, 700));

  // click on the submit button
  const submit = await frame.$('#signin-button');
  await cursor.click(submit);
}

(async () => {
 // start browser
 const command = GOOGLE_CHROME_BINARY + ' --remote-debugging-port=9222 --no-first-run --no-default-browser-check 2> browser.log &';
 execute(command, (stdout) => {
   console.log(stdout);
 });

 // now connect to the browser
 // we do not start the brwoser with puppeteer,
 // because we want to influence the startup process
 // as little as possible
 const browser = await puppeteer.connect({
   browserWSEndpoint: await getWsEndpoint(),
   defaultViewport: null,
 });

 const page = await browser.newPage();

 await page.goto('https://www.chase.com/');

 await page.waitForSelector('iframe#logonbox');

 const elementHandle = await page.$('iframe#logonbox');

 const frame = await elementHandle.contentFrame();

 await chaseLogin(page, frame);

 await sleep(4000);

 await page.screenshot({path: "chaseLogin.png", fullPage: true});

 await page.close();
 await browser.close();
})();